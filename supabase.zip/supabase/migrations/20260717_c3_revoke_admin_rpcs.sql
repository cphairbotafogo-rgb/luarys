-- C3: Revogar EXECUTE de funções administrativas SECURITY DEFINER do anon/authenticated
-- PROBLEMA: funções admin_ e outras SECURITY DEFINER são chamáveis via /rest/v1/rpc/
-- por qualquer visitante anônimo — permitem liberar módulos pagos de graça.
-- SOLUÇÃO: revogar EXECUTE para todos os roles não-privilegiados.

-- Funções cujas assinaturas estão nas migrations do projeto:
REVOKE EXECUTE ON FUNCTION public.admin_liberar_modulo_global(TEXT, INTEGER) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_revogar_promocao_global(TEXT) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.admin_listar_promocoes_ativas() FROM anon, authenticated;

-- Funções existentes no banco (criadas via SQL Editor) — usa pg_proc para
-- encontrá-las dinamicamente sem precisar conhecer as assinaturas exatas.
DO $$
DECLARE
  r RECORD;
  funcs TEXT[] := ARRAY[
    'admin_ativar_modulo_fiscal',
    'admin_ativar_modulo',
    'ativar_producao_fiscal',
    'comprar_pacote_whatsapp',
    'admin_conceder_acesso_total',
    'admin_revogar_acesso_total'
  ];
  fname TEXT;
BEGIN
  FOREACH fname IN ARRAY funcs LOOP
    FOR r IN
      SELECT p.oid::regprocedure::text AS sig
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'public' AND p.proname = fname
    LOOP
      BEGIN
        EXECUTE 'REVOKE EXECUTE ON FUNCTION ' || r.sig || ' FROM anon';
        EXECUTE 'REVOKE EXECUTE ON FUNCTION ' || r.sig || ' FROM authenticated';
        RAISE NOTICE 'Revogado: %', r.sig;
      EXCEPTION WHEN others THEN
        RAISE NOTICE 'Ignorado (não encontrado ou sem grant): %', r.sig;
      END;
    END LOOP;
  END LOOP;
END;
$$;

-- Verificação: lista funções admin_ que ainda aceitam anon/authenticated
-- (deve retornar vazio após rodar esta migration)
-- SELECT p.proname, a.rolname
-- FROM pg_proc p
-- JOIN pg_namespace n ON n.oid = p.pronamespace
-- JOIN pg_proc_acl pa ON pa.oid = p.oid  -- não é view padrão, use has_function_privilege()
-- WHERE n.nspname = 'public' AND p.proname LIKE 'admin_%';
